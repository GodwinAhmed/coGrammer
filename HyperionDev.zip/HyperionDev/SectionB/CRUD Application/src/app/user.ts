export class User{
    constructor(
        name:string,
        email:string,
        experience:number,
        domain:string
    ){}
}